import cv2
from ultralytics import YOLO
import socket as sc
import time

last_time=0

model = YOLO("yolo26n.pt")
HOST="10.201.189.168"
mySocket=sc.socket(sc.AF_INET,sc.SOCK_DGRAM)
mySocket.settimeout(5.0)
PORT=12345 
#width=640
#height= 360
width=1920
height= 1080

cam=cv2.VideoCapture(0,cv2.CAP_DSHOW)
cam.set(cv2.CAP_PROP_FRAME_WIDTH, width)
cam.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
cam.set(cv2.CAP_PROP_FPS, 30)
cam.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG"))

while True:
    ret, frame = cam.read()
    
    if not ret:
        break
    
    results = model(frame)
    
    count = 0
    
    for result in results:
    
        for box in result.boxes:
    
            class_id = int(box.cls[0])
    
            if class_id == 0:
                confidence=float(box.conf[0])
                if confidence>0.30:
                    count += 1
    
    annotated = results[0].plot()
    
    sendCount=str(count).encode()
    current_time=time.time()
    mySocket.sendto(sendCount,(HOST,PORT))
    
    cv2.putText(
        annotated,
        f"People: {count}",
        (20, 40),
        cv2.FONT_HERSHEY_SIMPLEX,
        1,
        (0, 255, 0),
        2
    )
    
    cv2.imshow("People Counter", annotated)
    
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
cam.release()
cv2.destroyAllWindows()
