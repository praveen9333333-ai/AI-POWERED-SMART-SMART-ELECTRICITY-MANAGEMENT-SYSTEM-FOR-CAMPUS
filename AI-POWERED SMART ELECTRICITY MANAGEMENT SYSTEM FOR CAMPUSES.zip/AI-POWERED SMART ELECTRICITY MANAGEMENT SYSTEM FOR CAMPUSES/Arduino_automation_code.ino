#include<WiFiS3.h>
#include<WiFiSSLClient.h>
#include<PubSubClient.h>
#include"secrets.h"

WiFiUDP udp;
WiFiSSLClient wifiClient;
PubSubClient mqtt(wifiClient);

int dataLen;
char myPacket[255];
int PORT=12345;
int data;
int bulb1=A0;
int bulb2=A1;
int fan1=A2;
int fan2=A3;
int fan3=A4;
int fan4=A5;
int manualPin=10;

int buttonPin=5;
int buttonOld=0;
int buttonNew;
int resetLight=4;
int reset=0;
int onLight=3;

int buzzPin=8;
int flag=1;

int buzzReset=0;
int BuzzButton=9;
int BuzzButNew=1;
int BuzzButOld=0;
int buzzResetLight=7;
int buzzOnLight=6;

const char* mqtt_server=
  "h1aa1a8a.ala.asia-southeast1.emqxsl.com";
const int mqtt_port=8883;
const char* client_id="ArduinoR4_Internet";
const char* mqtt_username="Arduino_R4";
const char* MQTT_COMMAND_TOPIC = "test/arduino/command";
const char* MQTT_STATUS_TOPIC = "test/arduino/status";
char iot_reset='1';

String condition[2]={"Automatic","Manual"};

const char* CA_CERT = R"EOF(
-----BEGIN CERTIFICATE-----
MIIDjjCCAnagAwIBAgIQAzrx5qcRqaC7KGSxHQn65TANBgkqhkiG9w0BAQsFADBh
MQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3
d3cuZGlnaWNlcnQuY29tMSAwHgYDVQQDExdEaWdpQ2VydCBHbG9iYWwgUm9vdCBH
MjAeFw0xMzA4MDExMjAwMDBaFw0zODAxMTUxMjAwMDBaMGExCzAJBgNVBAYTAlVT
MRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5j
b20xIDAeBgNVBAMTF0RpZ2lDZXJ0IEdsb2JhbCBSb290IEcyMIIBIjANBgkqhkiG
9w0BAQEFAAOCAQ8AMIIBCgKCAQEAuzfNNNx7a8myaJCtSnX/RrohCgiN9RlUyfuI
2/Ou8jqJkTx65qsGGmvPrC3oXgkkRLpimn7Wo6h+4FR1IAWsULecYxpsMNzaHxmx
1x7e/dfgy5SDN67sH0NO3Xss0r0upS/kqbitOtSZpLYl6ZtrAGCSYP9PIUkY92eQ
q2EGnI/yuum06ZIya7XzV+hdG82MHauVBJVJ8zUtluNJbd134/tJS7SsVQepj5Wz
tCO7TG1F8PapspUwtP1MVYwnSlcUfIKdzXOS0xZKBgyMUNGPHgm+F6HmIcr9g+UQ
vIOlCsRnKPZzFBQ9RnbDhxSJITRNrw9FDKZJobq7nMWxM4MphQIDAQABo0IwQDAP
BgNVHRMBAf8EBTADAQH/MA4GA1UdDwEB/wQEAwIBhjAdBgNVHQ4EFgQUTiJUIBiV
5uNu5g/6+rkS7QYXjzkwDQYJKoZIhvcNAQELBQADggEBAGBnKJRvDkhj6zHd6mcY
1Yl9PMWLSn/pvtsrF9+wX3N3KjITOYFnQoQj8kVnNeyIv/iPsGEMNKSuIEyExtv4
NeF22d+mQrvHRAiGfzZ0JFrabA0UWTW98kndth/Jsw1HKj2ZL7tcu7XUIOGZX1NG
Fdtom/DzMNU+MeKNhJ7jitralj41E6Vf8PlwUHBHQRFXGU7Aj64GxJUTFy8bJZ91
8rGOmaFvE7FBcf6IKshPECBV1/MUReXgRPTqh5Uykw7+U0b6LJ3/iyK5S9kJRaTe
pLiaWN0bfVKfjllDiIGknibVb63dDcY3fe0Dkhvld1927jyNxF1WW6LZZm6zNTfl
MrY=
-----END CERTIFICATE-----
)EOF";

void callback(char* topic,byte* payload,unsigned int length){
  if(length==1){
    iot_reset=(char)payload[0];
    if(iot_reset == '0'){
      reset = 0;
    }
    else if(iot_reset == '1'){
      reset = 1;
    }
    else{
      Serial.println("Invalid Input");
      return;
    }
    Serial.println("Message is: ");
    Serial.println(iot_reset);
    char message[30];

    sprintf(message, "Your current state is %s", condition[reset].c_str());

    mqtt.publish(MQTT_STATUS_TOPIC, message);
  }
  else {
    Serial.println("Invalid Input");
  }
}

void connectwifi(){
  Serial.println("Connecting to wifi");
  WiFi.begin(SSID,PASS);
  while(WiFi.status()!=WL_CONNECTED){
    Serial.print(".");
  }
  Serial.println("\nwifi connected succesfully");
  Serial.println(WiFi.localIP());
  Serial.println(WiFi.localIP());
}

void connectmqtt(){
  while(!mqtt.connected()){
    Serial.println("connecting to mqtt server");
    if(mqtt.connect(client_id,mqtt_username,mqtt_pass)){
      mqtt.subscribe(MQTT_COMMAND_TOPIC);
      Serial.println("mqtt_server_connected");
    }
    else{
      Serial.print("Server not connectd state is: ");
      Serial.println(mqtt.state());
    }
  }
}

void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);

  connectwifi();

  wifiClient.setCACert(CA_CERT);
  mqtt.setServer(mqtt_server,mqtt_port);
  mqtt.setCallback(callback);
  connectmqtt();

  udp.begin(PORT);
  Serial.println("port has been created successfully");
  Serial.println(PORT);

  pinMode(bulb1,OUTPUT);
  pinMode(bulb2,OUTPUT);
  pinMode(fan1,OUTPUT);
  pinMode(fan2,OUTPUT);
  pinMode(fan3,OUTPUT);
  pinMode(fan4,OUTPUT);
  pinMode(manualPin,OUTPUT);

  pinMode(resetLight,OUTPUT);
  pinMode(onLight,OUTPUT);
  pinMode(buttonPin, INPUT_PULLUP);
  pinMode(buzzPin,OUTPUT);

  pinMode(BuzzButton,INPUT_PULLUP);
  pinMode(buzzResetLight,OUTPUT);
  pinMode(buzzOnLight,OUTPUT);
}

void loop() {
  // put your main code here, to run repeatedly:
  if(!mqtt.connected()){
    connectmqtt();
  }

  mqtt.loop();
  
  buttonNew=digitalRead(buttonPin);
  if((buttonOld==0 && buttonNew==1)){
    if(reset==0){ 
      digitalWrite(manualPin,HIGH);
      digitalWrite(resetLight,HIGH);
      digitalWrite(onLight,LOW);
      reset=1;
      iot_reset='1';

      char message[30];
      sprintf(message, "Your current state is %s", condition[reset].c_str());
      mqtt.publish(MQTT_STATUS_TOPIC, message);
    }
    else{
      digitalWrite(manualPin,LOW);
      digitalWrite(resetLight,LOW);
      digitalWrite(onLight,HIGH);
      reset=0;
      iot_reset='0';

      char message[30];
      sprintf(message, "Your current state is %s", condition[reset].c_str());
      mqtt.publish(MQTT_STATUS_TOPIC, message);
    }
  }

  if(iot_reset=='0'){
    reset=0;
    digitalWrite(manualPin,LOW);
    digitalWrite(resetLight,LOW);
    digitalWrite(onLight,HIGH);
  }
  else if(iot_reset=='1'){
    reset=1;
    digitalWrite(manualPin,HIGH);
    digitalWrite(resetLight,HIGH);
    digitalWrite(onLight,LOW);
  }

  BuzzButNew=digitalRead(BuzzButton);
  if(BuzzButOld==0 && BuzzButNew==1){
    if(buzzReset==0){
      digitalWrite(buzzResetLight,LOW);
      digitalWrite(buzzOnLight,HIGH);
      buzzReset=1;
    }
    else{
      digitalWrite(buzzResetLight,HIGH);
      digitalWrite(buzzOnLight,LOW);
      buzzReset=0;
    }
  }
  if (reset==0){

    if(udp.parsePacket()){
      dataLen=udp.available();
      Serial.println(dataLen);
      udp.read(myPacket,254);
      myPacket[dataLen]=0;
      // Serial.println(myPacket);
      data=atoi(myPacket);
      Serial.println(data);

      if(data==0){
        if (flag==0 && buzzReset==1){
          for(int i=0;i<5;i++){
            digitalWrite(buzzPin,HIGH);
            unsigned long startTime = millis();
            while(millis() - startTime < 1000){
              if (udp.parsePacket()){
                dataLen=udp.available();
                udp.read(myPacket,254);
                myPacket[dataLen]=0;
                data=atoi(myPacket);
                if(data>0){
                  digitalWrite(buzzPin,LOW);
                  break;
                }
              }
            }
            if(data>0){
              break;
            }
            digitalWrite(buzzPin,LOW);
            delay(1000);
          }
          flag=1;
        }
        if (data==0){
          digitalWrite(bulb1,HIGH);
          digitalWrite(bulb2,HIGH);
          digitalWrite(fan1,HIGH);
          digitalWrite(fan2,HIGH);
          digitalWrite(fan3,HIGH);
          digitalWrite(fan4,HIGH);
        }
      }
      digitalWrite(buzzPin,LOW);
      if(data>=1 && data<2){
        flag=0;
        digitalWrite(buzzPin,LOW);
        digitalWrite(bulb1,LOW);
        digitalWrite(bulb2,HIGH);
        digitalWrite(fan1,LOW);
        digitalWrite(fan2,HIGH);
        digitalWrite(fan3,HIGH);
        digitalWrite(fan4,HIGH);
      }
      if(data>=2 && data<3){
        flag=0;
        digitalWrite(buzzPin,LOW);
        digitalWrite(bulb1,LOW);
        digitalWrite(bulb2,LOW);
        digitalWrite(fan1,LOW);
        digitalWrite(fan2,LOW);
        digitalWrite(fan3,HIGH);
        digitalWrite(fan4,HIGH);
      }
      if(data>=3 && data<4){
        flag=0;
        digitalWrite(buzzPin,LOW);
        digitalWrite(bulb1,LOW);
        digitalWrite(bulb2,LOW);
        digitalWrite(fan1,LOW);
        digitalWrite(fan2,LOW);
        digitalWrite(fan3,LOW);
        digitalWrite(fan4,HIGH);
      }
      if(data>=4){
        flag=0;
        digitalWrite(buzzPin,LOW);
        digitalWrite(bulb1,LOW);
        digitalWrite(bulb2,LOW);
        digitalWrite(fan1,LOW);
        digitalWrite(fan2,LOW);
        digitalWrite(fan3,LOW);
        digitalWrite(fan4,LOW);
      }
    }  
  }
  if(reset==1){
    digitalWrite(buzzPin,LOW);
    digitalWrite(bulb1,HIGH);
    digitalWrite(bulb2,HIGH);
    digitalWrite(fan1,HIGH);
    digitalWrite(fan2,HIGH);
    digitalWrite(fan3,HIGH);
    digitalWrite(fan4,HIGH);
  }
  // Serial.println(buttonNew);
  buttonOld=buttonNew;
  BuzzButOld=BuzzButNew;
  delay(50);
}
