# YOLO-Based Smart Room Automation System

## 1. Project Overview

The YOLO-Based Smart Room Automation System is an intelligent room automation project that uses computer vision to detect people and automate electrical appliances based on room occupancy.

The system uses YOLO for person detection, OpenCV for camera processing, an Arduino UNO R4 WiFi for hardware control, and MQTT for communication with a dashboard.

The goal is to reduce unnecessary electricity consumption by switching appliances according to room occupancy while allowing manual control when required.

## 2. Key Features

- Real-time person detection using YOLO.
- Camera processing using OpenCV.
- Automated room appliance control based on occupancy.
- Arduino UNO R4 WiFi for hardware interfacing.
- UDP communication between the computer and Arduino for occupancy data.
- MQTT communication for dashboard monitoring and control.
- Web-based dashboard with manual and automatic operating modes.
- Status monitoring and message exchange between the dashboard and Arduino.
- Support for controlling multiple lights and fans.

## 3. System Architecture

**Camera → Python + OpenCV + YOLO → UDP → Arduino UNO R4 WiFi → Relay Module → Electrical Appliances**

**Web Dashboard ↔ MQTT Broker ↔ Arduino UNO R4 WiFi**

The computer processes camera frames and detects people using YOLO. The occupancy information is sent to the Arduino through UDP. The Arduino uses the received information and the selected operating mode to control connected appliances.

The web dashboard communicates with the Arduino through an MQTT broker for monitoring and manual control.

## 4. Hardware Requirements

- Arduino UNO R4 WiFi
- USB webcam or compatible camera
- Computer or laptop capable of running YOLO
- Relay module compatible with the control circuit
- Suitable power supply for the controller and relay module
- Lights and fans or appropriate low-voltage demonstration loads
- Connecting wires and other required circuit components

## 5. Software Requirements

- Python 3
- OpenCV
- Ultralytics YOLO
- NumPy
- Arduino IDE
- Arduino UNO R4 WiFi board support package
- WiFiS3 library
- PubSubClient library
- MQTT broker (EMQX or another compatible broker)
- A modern web browser

## 6. Installation and Setup

### Step 1: Clone or Download the Repository

Clone the repository using Git:

```bash
git clone YOUR_GITHUB_REPOSITORY_URL
```

Alternatively, download the repository as a ZIP file and extract it.

### Step 2: Install Python Dependencies

Open a terminal in the project directory and run:

```bash
python -m pip install -r requirements.txt
```

### Step 3: Configure the Hardware

Connect the Arduino UNO R4 WiFi, relay module, and demonstration loads according to the circuit diagram and pin assignments in the source code.

Check the relay module's input voltage and logic requirements before connecting it.

### Step 4: Configure Network and MQTT Settings

Configure the Wi-Fi credentials, MQTT broker address, port, authentication details, and topic names as required by the source code.

Keep real credentials in a local configuration file that is excluded from GitHub. Never publish passwords, private keys, or access tokens.

### Step 5: Upload the Arduino Code

Open the Arduino source file in Arduino IDE, install the required board support and libraries, select the correct board and port, and upload the program.

### Step 6: Run the Python Application

Run the Python entry-point script specified in the project source code. Ensure the camera is connected and the computer and Arduino can communicate over the configured network.

If the project uses a local YOLO model file, make sure it is available at the path expected by the program.

### Step 7: Open the Dashboard

Open the project's HTML dashboard in a compatible browser or deploy it using the hosting method specified in the source code.

Configure the dashboard to connect to the correct MQTT broker and WebSocket endpoint.

## 7. Operating Modes

### Automatic Mode
The system uses camera-based person detection and occupancy information to automate connected appliances according to the programmed control logic.

### Manual Mode
The user can control supported appliances through the dashboard or the manual controls implemented in the hardware.

The exact behavior of mode switching and reset controls depends on the uploaded firmware.

## 8. Project Structure

```text
YOLO-Smart-Room-Automation/
├── Arduino/
│   └── Arduino_Controller.ino
├── Python/
│   └── yolo_occupancy.py
├── Dashboard/
│   └── index.html
├── requirements.txt
├── README.md
└── .gitignore
```

Adjust the folder and file names above to match the actual files in the repository.

## 9. Safety Notes

- Test the system with low-voltage demonstration loads before connecting mains-powered appliances.
- Do not handle exposed mains wiring while the system is powered.
- Use properly rated relays, insulation, enclosures, and protective devices.
- Keep Wi-Fi credentials, MQTT passwords, and other secrets out of the public repository.
- Do not assume that a software command alone guarantees electrical isolation or fail-safe operation.

## 10. Limitations and Future Improvements

Possible improvements include:

- Multi-zone occupancy tracking and more robust boundary-crossing logic.
- Better handling of temporary detection failures and camera occlusion.
- MQTT connection recovery and device availability monitoring.
- Secure MQTT communication and improved credential management.
- Energy consumption measurement and real-time savings analysis.
- Integration with additional sensors for occupancy verification.
- Improved fault handling and fail-safe appliance control.

## 11. Project Purpose

This project demonstrates the integration of computer vision, embedded systems, wireless communication, MQTT-based IoT control, and web-based monitoring for energy-aware room automation.

**Note:** Actual performance and energy savings depend on the implemented control logic, occupancy conditions, appliance ratings, and testing environment.